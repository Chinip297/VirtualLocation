package local.coordinatemock;

import android.app.*;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationManager;
import android.location.provider.ProviderProperties;
import android.os.*;
import java.util.ArrayList;
import java.util.List;

public class MockService extends Service {
    private static final String CHANNEL = "mock_location";
    private static final String STOP = "local.coordinatemock.STOP";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<String> providers = new ArrayList<>();
    private LocationManager manager;
    private Coordinates point;
    private boolean failed;
    private final Runnable tick = new Runnable() {
        public void run() {
            try {
                if (!manager.isLocationEnabled()) throw new IllegalStateException("系统定位已关闭");
                for (String provider : providers) {
                    Location location = new Location(provider);
                    location.setLatitude(point.latitude); location.setLongitude(point.longitude);
                    location.setAccuracy(5); location.setAltitude(0); location.setSpeed(0);
                    location.setTime(System.currentTimeMillis());
                    location.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
                    manager.setTestProviderLocation(provider, location);
                }
                state("模拟运行中：纬度 " + point.latitude + "，经度 " + point.longitude + "\n已写入：" + String.join(", ", providers));
                handler.postDelayed(this, 1000);
            } catch (RuntimeException e) { fail(e); }
        }
    };
    @Override public void onCreate() {
        super.onCreate(); manager = getSystemService(LocationManager.class);
        getSystemService(NotificationManager.class).createNotificationChannel(
            new NotificationChannel(CHANNEL, "模拟定位运行状态", NotificationManager.IMPORTANCE_LOW));
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        try {
            point = new Coordinates(intent.getDoubleExtra("latitude", Double.NaN), intent.getDoubleExtra("longitude", Double.NaN));
            failed = false;
            startForeground(1, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            if (providers.isEmpty()) {
                ProviderProperties properties = new ProviderProperties.Builder()
                    .setHasAltitudeSupport(true).setHasSpeedSupport(true)
                    .setAccuracy(ProviderProperties.ACCURACY_FINE)
                    .setPowerUsage(ProviderProperties.POWER_USAGE_LOW).build();
                for (String provider : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.FUSED_PROVIDER}) {
                    try {
                        manager.addTestProvider(provider, properties);
                        providers.add(provider);
                        manager.setTestProviderEnabled(provider, true);
                    } catch (SecurityException e) { throw e; }
                    catch (IllegalArgumentException e) { /* OEM may not support this provider. */ }
                }
                if (providers.isEmpty()) throw new IllegalStateException("设备没有接受任何模拟位置提供者");
            }
            handler.removeCallbacks(tick); tick.run();
        } catch (RuntimeException e) { fail(e); }
        return START_NOT_STICKY;
    }
    private Notification notification() {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, MockService.class).setAction(STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("经纬度模拟定位")
            .setContentText(point.latitude + ", " + point.longitude)
            .setContentIntent(open).setOngoing(true)
            .addAction(new Notification.Action.Builder(null, "停止", stop).build()).build();
    }
    private void state(String message) { getSharedPreferences("mock", MODE_PRIVATE).edit().putString("status", message).apply(); }
    private void fail(RuntimeException e) {
        failed = true;
        state(e instanceof SecurityException ? "权限不足：请在开发者选项选择本应用为模拟位置信息应用，并授予位置权限。" : "模拟已停止：" + e.getMessage());
        stopSelf();
    }
    @Override public void onDestroy() {
        handler.removeCallbacks(tick);
        for (String provider : providers) {
            try { manager.removeTestProvider(provider); } catch (RuntimeException ignored) { }
        }
        providers.clear();
        if (!failed) state("已停止；系统将重新获取实际位置");
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
