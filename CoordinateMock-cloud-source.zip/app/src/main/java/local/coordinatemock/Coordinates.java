package local.coordinatemock;

public final class Coordinates {
    public final double latitude, longitude;
    public Coordinates(double latitude, double longitude) {
        if (!Double.isFinite(latitude) || latitude < -90 || latitude > 90)
            throw new IllegalArgumentException("纬度必须在 -90 至 90 之间");
        if (!Double.isFinite(longitude) || longitude < -180 || longitude > 180)
            throw new IllegalArgumentException("经度必须在 -180 至 180 之间");
        this.latitude = latitude;
        this.longitude = longitude;
    }
    public static Coordinates parse(String latitude, String longitude) {
        try { return new Coordinates(Double.parseDouble(latitude.trim()), Double.parseDouble(longitude.trim())); }
        catch (NumberFormatException e) { throw new IllegalArgumentException("请输入十进制经纬度，例如 25.0330、121.5654"); }
    }
}
