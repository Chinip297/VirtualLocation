package local.coordinatemock;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private EditText latitude, longitude;
    private TextView status;
    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = new Runnable() {
        public void run() {
            status.setText(prefs.getString("status", "尚未启动"));
            handler.postDelayed(this, 1000);
        }
    };
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("mock", MODE_PRIVATE);
        ScrollView scroll = new ScrollView(this);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(24 * getResources().getDisplayMetrics().density);
        column.setPadding(pad, pad, pad, pad);
        scroll.setOnApplyWindowInsetsListener((view, insets) -> {
            android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars());
            column.setPadding(pad + bars.left, pad + bars.top, pad + bars.right, pad + bars.bottom);
            return insets;
        });
        scroll.addView(column);
        setContentView(scroll);
        TextView title = text(column, "经纬度模拟定位", 26);
        title.setTextColor(Color.rgb(22, 76, 95));
        text(column, "输入 WGS84 十进制坐标。纬度在前，经度在后。", 16);
        text(column, "纬度（-90 ～ 90）", 16);
        latitude = input(column, prefs.getString("latitude", ""), "例如 25.0330");
        text(column, "经度（-180 ～ 180）", 16);
        longitude = input(column, prefs.getString("longitude", ""), "例如 121.5654");
        button(column, "开始 / 更新位置", v -> startMock());
        button(column, "停止模拟定位", v -> {
            stopService(new Intent(this, MockService.class));
            prefs.edit().putString("status", "已停止；系统将重新获取实际位置").apply();
            status.setText(prefs.getString("status", ""));
        });
        button(column, "打开开发者选项", v -> {
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
            catch (RuntimeException e) { Toast.makeText(this, "请在系统设置中开启开发者选项", Toast.LENGTH_LONG).show(); }
        });
        button(column, "打开系统定位设置", v -> startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)));
        status = text(column, "尚未启动", 17);
        text(column, "首次使用：在开发者选项中，将“模拟位置信息应用”设为本应用，然后打开系统定位并授予位置权限。启动后可切换到其他应用；通知栏提供停止按钮。", 15);
        text(column, "系统会将这些坐标标记为模拟位置。其他应用可能拒绝此位置，或使用自己的定位来源。本工具只显示系统接口是否成功写入，不代表第三方应用已经接受。", 15);
    }
    private TextView text(LinearLayout parent, String value, int size) {
        TextView view = new TextView(this);
        view.setText(value); view.setTextSize(size); view.setPadding(0, 14, 0, 14);
        parent.addView(view); return view;
    }
    private EditText input(LinearLayout parent, String value, String hint) {
        EditText field = new EditText(this);
        field.setSingleLine(true); field.setHint(hint); field.setText(value);
        field.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        parent.addView(field); return field;
    }
    private void button(LinearLayout parent, String label, View.OnClickListener listener) {
        Button button = new Button(this); button.setText(label); button.setOnClickListener(listener); parent.addView(button);
    }
    private void startMock() {
        Coordinates point;
        try { point = Coordinates.parse(latitude.getText().toString(), longitude.getText().toString()); }
        catch (IllegalArgumentException e) { status.setText(e.getMessage()); return; }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
            status.setText("授予位置权限后，请再次点击开始"); return;
        }
        LocationManager manager = getSystemService(LocationManager.class);
        if (!manager.isLocationEnabled()) { status.setText("请先打开系统定位"); return; }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
        prefs.edit().putString("latitude", latitude.getText().toString().trim())
            .putString("longitude", longitude.getText().toString().trim()).apply();
        try {
            startForegroundService(new Intent(this, MockService.class)
                .putExtra("latitude", point.latitude).putExtra("longitude", point.longitude));
            status.setText("正在启动，请查看运行状态");
        } catch (RuntimeException e) { status.setText("无法启动：" + e.getMessage()); }
    }
    @Override protected void onResume() { super.onResume(); handler.post(refresh); }
    @Override protected void onPause() { handler.removeCallbacks(refresh); super.onPause(); }
}
