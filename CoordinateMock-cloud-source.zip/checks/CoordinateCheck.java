import local.coordinatemock.Coordinates;

public class CoordinateCheck {
    public static void main(String[] args) {
        Coordinates p = Coordinates.parse(" 25.0330 ", "121.5654");
        if (p.latitude != 25.0330 || p.longitude != 121.5654) throw new AssertionError("Coordinate order changed");
        new Coordinates(-90, -180);
        new Coordinates(90, 180);
        new Coordinates(0, 0);
        invalid("90.001", "0"); invalid("-90.001", "0");
        invalid("0", "180.001"); invalid("0", "-180.001");
        invalid("NaN", "0"); invalid("0", "Infinity");
        invalid("", "0"); invalid("north", "east");
        System.out.println("Coordinate validation checks passed");
    }
    private static void invalid(String lat, String lon) {
        try { Coordinates.parse(lat, lon); }
        catch (IllegalArgumentException expected) { return; }
        throw new AssertionError("Accepted invalid coordinates: " + lat + ", " + lon);
    }
}
