param([switch]$Prepare)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$projectRoot = $PSScriptRoot
$toolsRoot = Join-Path $projectRoot '.tools'
New-Item -ItemType Directory -Force -Path $toolsRoot | Out-Null
function Download-Zip($url, $name, $destination, $checksumUrl = '') {
    $archive = Join-Path $toolsRoot $name
    if (-not (Test-Path -LiteralPath $archive)) { Invoke-WebRequest -Uri $url -OutFile $archive -UseBasicParsing }
    if ($checksumUrl) {
        $expected = (Invoke-WebRequest -Uri $checksumUrl -UseBasicParsing).Content.Trim()
        if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected.ToLowerInvariant()) { throw "Checksum mismatch: $name" }
    }
    Expand-Archive -LiteralPath $archive -DestinationPath $destination -Force
}
$jdkRoot = Join-Path $toolsRoot 'jdk'
if (-not (Test-Path -LiteralPath $jdkRoot)) {
    Download-Zip 'https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/eclipse' 'jdk.zip' $jdkRoot
}
$jdkDirectory = Get-ChildItem -LiteralPath $jdkRoot -Directory | Select-Object -First 1
$env:JAVA_HOME = $jdkDirectory.FullName
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"
$gradleRoot = Join-Path $toolsRoot 'gradle-9.1.0'
if (-not (Test-Path -LiteralPath $gradleRoot)) {
    Download-Zip 'https://services.gradle.org/distributions/gradle-9.1.0-bin.zip' 'gradle.zip' $toolsRoot 'https://services.gradle.org/distributions/gradle-9.1.0-bin.zip.sha256'
}
$env:ANDROID_HOME = Join-Path $toolsRoot 'android-sdk'
$env:GRADLE_USER_HOME = Join-Path $toolsRoot 'gradle-cache'
$cliExtract = Join-Path $toolsRoot 'android-cli'
if (-not (Test-Path -LiteralPath $cliExtract)) {
    Download-Zip 'https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip' 'android-cli.zip' $cliExtract
}
$sdkManager = Join-Path $cliExtract 'cmdline-tools\bin\sdkmanager.bat'
if ($Prepare) {
    Write-Output 'Tool downloads complete. SDK installation will display license prompts.'
    & $sdkManager "--sdk_root=$env:ANDROID_HOME" 'platforms;android-36' 'build-tools;36.0.0' 'platform-tools'
    if ($LASTEXITCODE -ne 0) { throw 'SDK installation failed or license was not accepted.' }
}
if (-not (Test-Path -LiteralPath "$env:ANDROID_HOME\platforms\android-36\android.jar")) {
    throw 'Android SDK Platform 36 is missing. Run build-local.ps1 -Prepare and review the SDK license prompts.'
}
Push-Location $projectRoot
try {
    & "$gradleRoot\bin\gradle.bat" --no-daemon wrapper --gradle-version 9.1.0 :app:assembleDebug :app:lintDebug
    if ($LASTEXITCODE -ne 0) { throw 'Build or lint failed.' }
} finally { Pop-Location }
