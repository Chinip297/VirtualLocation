# 经纬度模拟定位

使用 Android 标准测试位置接口的本地工具。目标 Android 16（API 36），最低 Android 12。输入 WGS84 十进制纬度、经度，以前台服务每秒写入系统测试位置提供者。无网络权限，无账号，无上传功能。

这是模拟定位工具。Android 会标记模拟位置，不能保证微信或任何第三方小程序读取、接受该位置，也不能保证打卡成功。界面中的“已写入”仅代表系统接口调用成功。

## 安装和使用

1. 安装编译生成的 APK。
2. 在手机系统设置开启开发者选项（不同品牌入口不同），找到“选择模拟位置信息应用”，选择“经纬度模拟定位”。
3. 开启系统定位，打开本应用，授予使用期间位置权限。建议允许通知，方便停止。
4. 输入纬度（-90～90）和经度（-180～180），点击“开始 / 更新位置”。南纬、西经用负数。
5. 等待运行状态显示写入成功，再在所需应用中自行验证位置。
6. 使用结束后点击“停止模拟定位”，或通知栏“停止”。系统重新获取真实定位可能需要时间；其他应用也可能暂存旧坐标。

输入示例：纬度 `25.0330`、经度 `121.5654`。示例只用于格式说明。
输入必须是 WGS84 坐标。本版不提供 GCJ-02、BD-09 坐标转换，不应直接粘贴其他坐标系的地图坐标。

服务不会在重启后自动启动，进程被系统终止后也不会自动恢复。部分厂商后台限制可能停止服务。运行状态是上次服务写入的状态，不能代替第三方应用实际定位结果。

## 编译

### 云端构建（电脑不需要安装编译工具）

工程已经包含 `.github/workflows/build-apk.yml`。在有 GitHub Actions 权限的仓库中上传本工程内容，确保 `app`、`settings.gradle` 和 `.github` 位于仓库根目录。上传时不要包含 `.tools`。

在 GitHub 仓库 Actions 页选择 `Build Android APK`，点击 `Run workflow`。成功后下载 `CoordinateMock-APK` 构建产物 ZIP，其中包括调试签名的 `CoordinateMock-1.0.apk` 和 SHA256 校验文件。产物保留 7 天。

云端流程会运行坐标范围检查、APK 编译、Android lint。尚未运行成功的工作流不代表 APK 已生成。构建会使用仓库所属账户的 Actions 资源和额度，具体可用性由该账户决定。调试签名适合手动测试安装，不适合作为商店发行签名。

### 本地构建

环境：JDK 17、Gradle 9.1.0、Android SDK Platform 36、Build Tools 36.0.0。插件版本 AGP 9.0.1。

在 Android Studio 打开本目录，配置 Android SDK、同步后选择 Build APK(s)。若提示缺少 Gradle Wrapper，选择本地 Gradle 9.1.0，执行 `gradle wrapper --gradle-version 9.1.0` 后重新导入。

命令行：配置 `ANDROID_HOME` 和 `JAVA_HOME` 后执行 `gradle :app:assembleDebug`。输出路径：`app/build/outputs/apk/debug/app-debug.apk`。

未编译、未在 Android 16 真机验证时，不应视为已确认可运行版本。

## 官方接口资料

- https://developer.android.com/reference/android/location/LocationManager
- https://developer.android.com/reference/android/location/Location#isMock()
- https://developer.android.com/develop/background-work/services/fgs/service-types#location
- https://developer.android.com/build/releases/agp-9-0-0-release-notes
